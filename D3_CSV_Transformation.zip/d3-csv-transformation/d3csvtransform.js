//var margin = { top:0, right:0, bottom:20, left:50 },
//add additional top margin to make room for label
var margin = {top:50, right:0, bottom:20, left:50}
    width = 800,
    height = 500;

//var dollarFormat = function(d) { retrun '$' + d3.format(',f')(d) };

var svg = d3.select("body")
    .append("svg")
    .attr("width", "100%")
    .attr("height", "100%")
    .attr("viewBox", "0 0 800 500");

var yScale = d3.scaleLinear()
    .range([height - margin.top - margin.bottom, 0]);
var xScale = d3.scaleBand()
    .rangeRound([0, width - margin.right - margin.left], .1);

//var xAxis = d3.svg.axis()
    //.scale(xScale)
    //.orient("bottom");

var xAxis = d3.axisBottom(xScale);

//var yAxis = d3.svg.axis()
    //.scale(yScale)
    //.orient("left");

//var yAxis = d3.axisLeft(yScale);


//go back to where you created yAxis
var yAxis = d3.axisLeft(yScale);
    //.tickFormat(function(d) { retrun '$' + d3.format(',f')(d) });
    //.tickFormat(d3.format("$, ")); //...then add this line, a tickFormat for currency

d3.csv("Stock ownership.csv", function (error, data) {

    data = data.map(function(d){
        d["Median Price"] = +d["Median Price"];
        return d;
    });

    //yscale's domain is from zero to the maximum "Median Price" in your data
    yScale.domain([0, d3.max(data, function(d){ return d["Median Price"]; })]);
    //yScale.domain([0, 140000]);

    //xscale is unique values in your data (Age Group, since they are all different)
    xScale.domain(data.map(function(d) { return d["Age Group"]; }));

    svg.append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        .selectAll(".bar")
        .data(data)
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("x", function(d) { return xScale(d["Age Group"]); })
        .attr("y", function(d) { return yScale(d["Median Price"]); })
        .attr("height", function(d) { return height - margin.top - margin.bottom - yScale(d["Median Price"]); })
        .attr("width", function(d) { return xScale.bandwidth(); });

    //adding y axis to the left of the chart
    svg.append("g")
        .attr("class","y axis")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        .call(yAxis);

    //adding x axis to the bottom of chart
    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(" + margin.left + "," + (height - margin.bottom) + ")")
        .call(xAxis);

    yScale.domain([0, 140000]);

    //add text labels to the top of each bar
    svg.append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        .selectAll(".textlabel")
        .data(data)
        .enter()
        .append("text")
        .attr("class", "textlabel")
        .attr("x", function(d){ return xScale(d["Age Group"]) + (xScale.bandwidth()/2); })
        .attr("y", function(d){ return yScale(d["Median Price"]) - 3; })
        .text(function(d){ return d3.format("$,")(d["Median Price"]); });

    //add additional top margin to make room for label

    /*//adding a label at the top of the chart
    svg.append("g")
        .attr("transform", "translate(" + (width/2) + ", 15)")
        .append("text")
        .text("Stock Wealth by Age")
        .style({"text-anchor":"middle", "font-family":"Arial", "font-weight":"800"});*/
});

(function(){
    var margin = {top:50, right:0, bottom:20, left:50}
    svg.append("g")
        .attr("transform", "translate(" + (width/2) + ", 15)")
        .append("text")
        .text("Stock Wealth by Age")
        .style({"text-anchor":"middle", "font-family":"Arial", "font-weight":"800"});
});
